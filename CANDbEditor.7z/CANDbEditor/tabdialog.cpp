/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtWidgets>

#include "tabdialog.h"

TabDialogMess::TabDialogMess(const MainDbCommonItem *item, QWidget *parent)
    : QDialog(parent)
{
    QString s = "asdfd";
    tabWidget = new QTabWidget;
    DeTabSign = new DefinitionTabSignal(item);
    MsgTab = new MessageTab(s);
    ReceiSignTabSign =new ReceiversTabSignal(s);
    AtTabSign = new AttributesTabSignal(s);
    ValueDeTabSign = new ValueDescriptionsTabSignal(s);
    ComTabSign = new CommentTabSignal(item->data(9).toString());
    tabWidget->addTab(DeTabSign, tr("Definition"));
    tabWidget->addTab(MsgTab, QIcon(":/icons/message.png"), tr("Message"));
    tabWidget->addTab(ReceiSignTabSign, QIcon(":/icons/network.png"), tr("Receivers"));
    tabWidget->addTab(AtTabSign, QIcon(":/icons/edit.png"), tr("Attributes"));
    tabWidget->addTab(ValueDeTabSign, tr("Value Descriptions"));
    tabWidget->addTab(ComTabSign, tr("Comment"));

    buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok
                                     | QDialogButtonBox::Cancel
                                     | QDialogButtonBox::Apply
                                     | QDialogButtonBox::Help);

    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(tabWidget);
    mainLayout->addWidget(buttonBox);
    setLayout(mainLayout);

    setWindowTitle(("Signal '" + item->data(0).toString() + "'"));
}

DefinitionTabSignal::DefinitionTabSignal(const MainDbCommonItem *item, QWidget *parent)
    : QWidget(parent)
{
    QLabel *fileNameLabel = new QLabel(tr("Name:"));
    QLineEdit *fileNameEdit = new QLineEdit(item->data(0).toString());

    QLabel *Length = new QLabel(tr("Length [Bit]:"));
    QLineEdit *LengthEdit = new QLineEdit(item->data(1).toString());

    QLabel *ByteOrder = new QLabel(tr("Byte Order:"));
    QComboBox *ByteOrderEdit = new QComboBox;
    ByteOrderEdit->addItem("Intel");
    ByteOrderEdit->addItem("Motorola");
    if(!QString("Intel").compare(item->data(2).toString())){
        qDebug()<<"intel";
        ByteOrderEdit->setCurrentIndex(0);
    }else{
        ByteOrderEdit->setCurrentIndex(1);
        qDebug()<<"moto";
    }

    QLabel *Unit = new QLabel(tr("Unit:"));
    QLineEdit *UnitEdit = new QLineEdit(item->data(0).toString());

    QLabel *ValueType = new QLabel(tr("Value Type:"));
    QComboBox *ValueTypeEdit = new QComboBox;
    ValueTypeEdit->addItem("Signed");
    ValueTypeEdit->addItem("Unsigned");
    ValueTypeEdit->addItem("Float");
    ValueTypeEdit->addItem("Double");
    qDebug()<<"Type value "<<item->data(3).toString();
    if(!QString("Signed").compare(item->data(3).toString())){
        qDebug()<<"signed";
        ValueTypeEdit->setCurrentIndex(0);
    }else if(!QString("Unsigned").compare(item->data(3).toString())){
        qDebug()<<"unsigned";
        ValueTypeEdit->setCurrentIndex(1);
    }else if(!QString("Float").compare(item->data(3).toString())){
        qDebug()<<"float";
        ValueTypeEdit->setCurrentIndex(2);
    }else {
        qDebug()<<"double";
        ValueTypeEdit->setCurrentIndex(3);
    }


    QLabel *IntValue = new QLabel(tr("Int. Value:"));
    QLineEdit *IntValueEdit = new QLineEdit(item->data(4).toString());


    QLabel *Factor = new QLabel(tr("Factor:"));
    QLineEdit *FactorEdit = new QLineEdit(item->data(5).toString());

    QLabel *Offset = new QLabel(tr("Offset:"));
    QLineEdit *OffsetEdit = new QLineEdit(item->data(6).toString());

    QLabel *Minimum = new QLabel(tr("Minimum:"));
    QLineEdit *MinimumEdit = new QLineEdit(item->data(7).toString());

    QLabel *Maximum = new QLabel(tr("Maximum:"));
    QLineEdit *MaximumEdit = new QLineEdit(item->data(8).toString());

    QLabel *ValueTable = new QLabel(tr("Value Table:"));
    QComboBox *ValueTableEdit = new QComboBox;
    ValueTableEdit->addItem("<none>");
    ValueTableEdit->addItem("Vt Ev_EvGwSwitchlgnition");
    ValueTableEdit->addItem("VtSin_Active");

    QCheckBox *Automatic = new QCheckBox(tr("Automatic min-max calculation"));

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(fileNameLabel,0,0,1,1);
    mainLayout->addWidget(fileNameEdit,0,1,1,3);
    mainLayout->addWidget(Length,1,0,1,1);
    mainLayout->addWidget(LengthEdit,1,1,1,1);
    mainLayout->addWidget(ByteOrder,2,0,1,1);
    mainLayout->addWidget(ByteOrderEdit,2,1,1,1);
    mainLayout->addWidget(Unit,2,2,1,1);
    mainLayout->addWidget(UnitEdit,2,3,1,1);
    mainLayout->addWidget(ValueType,3,0,1,1);
    mainLayout->addWidget(ValueTypeEdit,3,1,1,1);
    mainLayout->addWidget(IntValue,3,2,1,1);
    mainLayout->addWidget(IntValueEdit,3,3,1,1);
    mainLayout->addWidget(Factor,4,0,1,1);
    mainLayout->addWidget(FactorEdit,4,1,1,1);
    mainLayout->addWidget(Offset,4,2,1,1);
    mainLayout->addWidget(OffsetEdit,4,3,1,1);
    mainLayout->addWidget(Minimum,5,0,1,1);
    mainLayout->addWidget(MinimumEdit,5,1,1,1);
    mainLayout->addWidget(Maximum,5,2,1,1);
    mainLayout->addWidget(MaximumEdit,5,3,1,1);
    mainLayout->addWidget(ValueTable,6,0,1,1);
    mainLayout->addWidget(ValueTableEdit,6,1,1,3);
    mainLayout->addWidget(Automatic,7,0,1,2);
    setFixedSize(300,300);
    setLayout(mainLayout);
}

MessageTab::MessageTab(const QString s, QWidget *parent)
    : QWidget(parent)
{
    buttonAdd = new QPushButton(tr("Add"));
    buttonRemove = new QPushButton(tr("Remove"));
    buttonView = new QPushButton(tr("View"));
    signal = new QTableWidget(10,4,0);
    m1_TableHeader<<"Name"<< "ID"<<"ID-format"<<"DLC[Byte]";
    signal->setHorizontalHeaderLabels(m1_TableHeader);
    signal->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);

    signal->verticalHeader()->setVisible(false);
    signal->setShowGrid(false);
    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,10,8);
    mainLayout->addWidget(buttonAdd,10,0,1,1);
    mainLayout->addWidget(buttonRemove,10,1,1,1);
    mainLayout->addWidget(buttonView,10,10,1,1);
    setLayout(mainLayout);
}

ReceiversTabSignal::ReceiversTabSignal(const QString s, QWidget *parent)
    : QWidget(parent)
{
    buttonView = new QPushButton(tr("View"));
    QTreeWidget *signal = new QTreeWidget;
    signal->setColumnCount(2);
    signal->setHeaderLabels(QStringList() << "Name"<< "Address");

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,10,8);
    mainLayout->addWidget(buttonView,10,10,1,1);
    setLayout(mainLayout);
}

AttributesTabSignal::AttributesTabSignal(const QString s, QWidget *parent)
    : QWidget(parent)
{
    QTextEdit *CommentEdit = new QTextEdit(s);
    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addWidget(CommentEdit);
    setLayout(Layout);
}

ValueDescriptionsTabSignal::ValueDescriptionsTabSignal(const QString s, QWidget *parent)
    : QWidget(parent)
{
    buttonAdd = new QPushButton(tr("Add"));
    buttonRemove = new QPushButton(tr("Remove"));
    buttonView = new QPushButton(tr("View"));
    signal = new QTableWidget(10,2,0);
    m1_TableHeader<<"Name"<< "Address";
    signal->setHorizontalHeaderLabels(m1_TableHeader);
    signal->verticalHeader()->setVisible(false);
    signal->setShowGrid(false);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(signal,0,0,10,8);
    mainLayout->addWidget(buttonAdd,10,0,1,1);
    mainLayout->addWidget(buttonRemove,10,1,1,1);
    mainLayout->addWidget(buttonView,10,10,1,1);
    setLayout(mainLayout);
}

CommentTabSignal::CommentTabSignal(const QString s, QWidget *parent)
    : QWidget(parent)
{
    QTextEdit *CommentEdit = new QTextEdit(s);
    QVBoxLayout *Layout = new QVBoxLayout;
    Layout->addWidget(CommentEdit);
    setLayout(Layout);
}
